# ML Breast Cancer Classifier

A clean starter ML project for a university application or portfolio.

## Task
Binary classification: predict whether a tumor is malignant or benign using the scikit-learn Breast Cancer dataset.

## Model
Logistic Regression with standardized features.

## Project structure

```text
ml-breast-cancer-classifier/
├── src/
│   ├── preprocess.py
│   ├── train.py
│   └── evaluate.py
├── tests/
│   └── test_preprocess.py
├── models/
├── logs/
├── requirements.txt
├── environment.yml
├── .gitignore
└── README.md
```

## Setup

### pip
```bash
python -m venv .venv
source .venv/bin/activate   # macOS/Linux
pip install -r requirements.txt
```

### conda
```bash
conda env create -f environment.yml
conda activate ml-breast-cancer
```

## Train
```bash
python src/train.py --seed 42 --c 1.0 --max-iter 1000
```

## Evaluate
```bash
python src/evaluate.py --model-path models/model.pkl --metrics-path logs/metrics.json
```

## Reproducibility
- Python `random`, NumPy, and scikit-learn `random_state` are seeded.
- Split is stratified for class balance.
- CPU execution is used; tiny floating point variations may still exist across library versions or BLAS backends.

## Dataset
- **Name:** Breast Cancer Wisconsin Diagnostic Dataset
- **Samples:** 569
- **Features:** 30 numeric features
- **Source:** scikit-learn built-in dataset
- **License:** BSD-style scikit-learn distribution terms

## Suggested Git workflow
Make at least 3 commits after creating your repo:
1. `git commit -m "add preprocessing pipeline"`
2. `git commit -m "add training and evaluation scripts"`
3. `git commit -m "add tests and reproducibility notes"`

## Important
Use this as a starter project. Read it, run it, and make small changes so you can honestly explain every line in your application.
