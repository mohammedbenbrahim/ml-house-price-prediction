from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, log_loss

from preprocess import prepare_splits, set_global_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a breast cancer classifier.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--c", type=float, default=1.0, help="Inverse regularization strength")
    parser.add_argument("--max-iter", type=int, default=1000)
    parser.add_argument("--model-path", type=str, default="models/model.pkl")
    parser.add_argument("--metrics-path", type=str, default="logs/metrics.json")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_global_seed(args.seed)
    split_data = prepare_splits(seed=args.seed)

    model = LogisticRegression(
        C=args.c,
        max_iter=args.max_iter,
        random_state=args.seed,
        solver="lbfgs",
    )
    model.fit(split_data.X_train, split_data.y_train)

    val_probs = model.predict_proba(split_data.X_val)[:, 1]
    val_preds = (val_probs >= 0.5).astype(int)

    metrics = {
        "seed": args.seed,
        "model": "LogisticRegression",
        "val_loss": round(log_loss(split_data.y_val, val_probs), 6),
        "val_accuracy": round(accuracy_score(split_data.y_val, val_preds), 6),
        "val_f1": round(f1_score(split_data.y_val, val_preds), 6),
        "hyperparameters": {
            "C": args.c,
            "max_iter": args.max_iter,
            "solver": "lbfgs",
        },
    }

    model_path = Path(args.model_path)
    metrics_path = Path(args.metrics_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    metrics_path.parent.mkdir(parents=True, exist_ok=True)

    joblib.dump(model, model_path)
    metrics_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    print(
        f"val_loss={metrics['val_loss']:.6f} "
        f"val_accuracy={metrics['val_accuracy']:.6f} "
        f"val_f1={metrics['val_f1']:.6f} "
        f"checkpoint={model_path}"
    )


if __name__ == "__main__":
    main()
