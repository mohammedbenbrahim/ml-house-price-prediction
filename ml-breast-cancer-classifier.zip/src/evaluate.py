from __future__ import annotations

import argparse
import json

import joblib
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score

from preprocess import prepare_splits


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate the trained model on the test split.")
    parser.add_argument("--model-path", type=str, default="models/model.pkl")
    parser.add_argument("--metrics-path", type=str, default="logs/metrics.json")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    split_data = prepare_splits(seed=args.seed)
    model = joblib.load(args.model_path)

    test_preds = model.predict(split_data.X_test)
    test_acc = accuracy_score(split_data.y_test, test_preds)
    test_f1 = f1_score(split_data.y_test, test_preds)
    cm = confusion_matrix(split_data.y_test, test_preds)

    print(f"test_accuracy={test_acc:.6f}")
    print(f"test_f1={test_f1:.6f}")
    print("confusion_matrix=")
    print(cm)
    print("classification_report=")
    print(classification_report(split_data.y_test, test_preds))

    with open(args.metrics_path, "r", encoding="utf-8") as f:
        metrics = json.load(f)
    print("saved_validation_metrics=")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
