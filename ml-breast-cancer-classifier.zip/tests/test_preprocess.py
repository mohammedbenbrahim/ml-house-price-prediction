from src.preprocess import prepare_splits


def test_prepare_splits_shapes_and_balance() -> None:
    split_data = prepare_splits(seed=42)

    assert split_data.X_train.shape[1] == 30
    assert split_data.X_val.shape[1] == 30
    assert split_data.X_test.shape[1] == 30

    total_rows = (
        split_data.X_train.shape[0]
        + split_data.X_val.shape[0]
        + split_data.X_test.shape[0]
    )
    assert total_rows == 569
    assert len(split_data.feature_names) == 30
